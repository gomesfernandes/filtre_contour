package filtres_contour;

abstract class Filtre {
	abstract int[][] process(int [][] img, int w, int h) ;
}
