package filtres_contour;

import java.io.IOException;

public class ApplicationFiltres {
	public static void main(String args[]) {
		try {
			View v = new View();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
