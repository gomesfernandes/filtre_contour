compilez avec
javac filtres_contour/*.java -classpath commons-math3-3.6.1.jar

lancez avec
java -cp commons-math3-3.6.1.jar:. filtres_contour/ApplicationFiltres